<?php
/*
Plugin Name: mySTAT
Plugin URI: http://sandbox.net.ua/mystat/
Description: myStat is a flexible and versatile system intended for accumulation and analysis of the site attendance statistics. myStat suits to upcoming projects perfectly. There are more than 50 reports available in the system. The system is easy to install and to set up; it allows counting all the visitors of your web-site - both humans and robots. All visits data is stored at your server, which meets safety and confidentiality requirements.
Version: 3.0
Author: Smyshlaev Evgeniy
Author URI: http://www.hide.com.ua
*/

define("VERSION","3.0");
require_once(dirname(__FILE__).'/component/common.class.php');

class myStat extends common{

  public function printMainPage($el=''){
    echo $this->printScript();
    $this->checkServer();
    echo "<script type=\"text/javascript\">";
    echo <<<EOS
  Ext.onReady(function(){
    view = new Ext.Panel({
      layout: 'border',
      border: false,
      items: [{
        region: 'center',
        xtype: 'panel',
//        title: 'Default Tab',
        html: 'The first tab\'s content. Others may be added dynamically'
      },{
        region: 'east',
        collapsible: true,
//        title: 'Navigation',
        width: 200
      }]
    });
    view.height = document.getElementById('wpwrap').offsetHeight;
    view.render('myStat_main');
//  view.setHeight(200,true);
//  Ext.fly('myStat_main').setHeight(200, true);
  });
EOS;
    echo "</script>";

  }

  private function printScript(){
    return '<style type="text/css">'."\n".
      '@import url('.$this->getUri().'/css/main.css)'."\n".
      '</style>'."\n".
      '<script type="text/javascript" src="'.$this->getUri().'/js/ext/adapter/ext/ext-base.js"></script>'."\n";
//      '<style type="text/css">'."\n".
//      '@import url('.$this->getUri().'/js/ext/resources/css/ext-all.css)'."\n".
//      '</style>'."\n".
//      '<script type="text/javascript" src="'.$this->getUri().'/js/ext/adapter/ext/ext-base.js"></script>'."\n".
//      '<script type="text/javascript" src="'.$this->getUri().'/js/ext/ext-all.js"></script>'."\n".
//      '<script type="text/javascript" src="'.$this->getUri().'/js/ext/src/locale/ext-lang-'.$this->getCulture().'.js"></script>'."\n".
//      '<script type="text/javascript" src="'.$this->getUri().'/js/ext/src/ext-core/src/core/Loader.js"></script>'."\n";
  }

}

global $stat;
$stat = new myStat();

include_once(dirname(__FILE__).'/wordpress.php');

if($stat->hasPrint()){
  $stat->printMainPage();
};