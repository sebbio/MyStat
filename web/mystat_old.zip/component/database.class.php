<?php

class database{
  
  private $conn = null;

  public function connect(){
    if(is_null($this->conn)){
      $this->conn = $GLOBALS['wpdb'];
    }
    return $this->conn;
  }

  public function query($str){
  }

  public function disconnect(){
  }

  public function getPrefix(){
    return $GLOBALS['wpdb']->prefix;
  }

}