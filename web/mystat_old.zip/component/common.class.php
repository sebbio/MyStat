<?php

require_once(dirname(__FILE__).'/database.class.php');

class common extends database{

  public function getParam($name, $default=''){
    $return = get_option($name);
    if($return!=''){
      return $return;
    };
    return $default;
  }

  public function setParam($name, $value){
    if($this->hasParam($name)){
      update_option($name,$value);
      return true;
    };
    add_option($name,$value);
    return false;
  }

  public function delParam($name){
    delete_option($name);
    return true;
  }

  public function hasParam($name){
    if($this->getParam($name,null)!=null){
      return true;
    };
    return false;
  }

  public function getCulture(){
    return "ru";
  }

  public function checkServer(){
    $complete = true;
    if(!function_exists("preg_match")){
      $complete = false;  
    };
    if(!function_exists("ini_set")){
      $complete = false;  
    };
    return $complete;
  }

  public function hasPrint(){
    return false;
  }

  public function getUri(){
    return WP_PLUGIN_URL."/".dirname(dirname(plugin_basename(__FILE__)));
  }

}