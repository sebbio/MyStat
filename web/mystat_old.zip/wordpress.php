<?php
if(!defined('VERSION')){die('Hacking attempt');};

function myStat_install(){
    global $wpdb;
    global $wp_db_version;
    global $stat;

    $table_name = $wpdb->prefix . "myStat_main";
    if($wp_db_version >= 5540) $page = 'wp-admin/includes/upgrade.php'; else $page = 'wp-admin/upgrade'.'-functions.php';
    require_once(ABSPATH . $page);

$sql = "CREATE TABLE ".$wpdb->prefix."myStat_data (
type enum('1','2','3','4','5','6') NOT NULL default '1',
value1 varchar(255) NOT NULL default '',
value2 varchar(255) NOT NULL default '',
value3 varchar(255) NOT NULL default '',
value4 varchar(255) NOT NULL default '',
KEY type (type)
);";
dbDelta($sql);
$sql="CREATE TABLE ".$wpdb->prefix."myStat_dbsize (
date date NOT NULL default '0000-00-00',
size int(11) unsigned NOT NULL default '0',
PRIMARY KEY  (date)
);";
dbDelta($sql);
$sql="CREATE TABLE ".$wpdb->prefix."myStat_main (
id int(11) unsigned NOT NULL auto_increment,
date timestamp NOT NULL default '0000-00-00 00:00:00',
date_load timestamp NOT NULL default '0000-00-00 00:00:00',
ip int(11) NOT NULL default '0',
proxy enum('0','1') NOT NULL default '0',
code_stat int(11) unsigned NOT NULL default '404',
feed enum('yes','no') NOT NULL default 'no',
user varchar(60) NOT NULL default '',
title varchar(255) NOT NULL default '',
host varchar(100) NOT NULL default '',
www enum('yes','no') NOT NULL default 'no',
page varchar(255) NOT NULL default '',
uri text NOT NULL default '',
post_id int(11) NOT NULL default 0,
user_agent text NOT NULL default '',
referer text NOT NULL default '',
lang char(2) NOT NULL default '',
country varchar(150) NOT NULL default '',
city varchar(32) NOT NULL default '',
screen varchar(9) NOT NULL default '',
depth enum('','8','16','32','48','64','128') NOT NULL default '',
gzip enum('0','1') NOT NULL default '0',
cookie enum('0','1') NOT NULL default '0',
js varchar(4) NOT NULL default '',
flash varchar(20) NOT NULL default '',
java enum('0','1') NOT NULL default '0',
count int(11) unsigned NOT NULL default '0',
PRIMARY KEY  (id),
KEY indx1 (date,ip)
);";
dbDelta($sql);
    $stat->setParam("myStat_version",VERSION);
    if($stat->hasParam("myStat_saveday")){$stat->setParam("myStat_saveday",90);};
    if($stat->hasParam("myStat_show_post_stat")){$stat->setParam("myStat_show_post_stat",0);};
}




function myStat_deinstall(){
    global $wpdb;
    global $stat;
    $table_name = $wpdb->prefix() . "myStat_main";
    $res = $wpdb->get_results("SHOW TABLES LIKE '$table_name'", ARRAY_N);
    if($res[0] != $table_name) {
        $stat->delParam("myStat_version");
        $stat->delParam("myStat_saveday");
        $stat->delParam("myStat_lastupdate");
        $stat->delParam("myStat_show_post_stat");
    };
}




function myStat_menu(){
    global $wpdb;
    global $stat;
    $table_name = $wpdb->prefix . "myStat_main";
    $res = $wpdb->get_results("SHOW TABLES LIKE '$table_name'", ARRAY_N);
    if($res != $table_name) {
        myStat_install();
    }
    $mincap="level_8";
    add_menu_page('myStat', '<b>myStat</b>', $mincap, dirname(__FILE__)."/index.php", 'myStat_mainPage',WP_PLUGIN_URL."/".dirname(plugin_basename(__FILE__)).'/images/admin.png');
    add_submenu_page(dirname(__FILE__)."/index.php", __('Overview','myStat'), __('Overview','myStat'), $mincap, dirname(__FILE__)."/index.php", 'myStat_mainPage');
}




function myStat_mainpage(){
  global $stat;
  echo '<br/><table border="0" cellspacing="0" width="99%" cellpadding="0">';
  echo '<tr height="21px"><td colspan="3" align="left"><img width="102px" height="21px" src="'.$stat->getUri().'/images/110.png"/></td></tr>';
  echo '<tr height="22px"><td width="102"><img width="102px" height="22px" src="'.$stat->getUri().'/images/111.png"/></td><td style="background:url('.$stat->getUri().'/images/12.png)" width="100%" align="right" valign="middle"><a style="font-size:9px;cursor:default;">';
#  echo $this->cmn->T("Version");
  echo ': <b>';
  echo VERSION;
  echo '</b></a></td><td width="19px"><img width="19px" height="22px" src="'.$stat->getUri().'/images/13.png"/></td></tr>';
  echo '<tr height="21px"><td colspan="3" align="left"><img width="22px" height="21px" src="'.$stat->getUri().'/images/112.png"/></td></tr></table>';

  echo '<table border="0" cellspacing="0" cellpadding="0" height="100%" style="background:url('.$stat->getUri().'/images/fon.png) no-repeat center 100px;">';
  echo '<tr height="22px">';
  echo '<td width="24px"><img width="24px" height="22px" src="'.$stat->getUri().'/images/201.png"/></td>';
  echo '<td style="background:url('.$stat->getUri().'/images/202.png);" width="100%">&nbsp;</td>';
  echo '<td width="23px"><img width="23px" height="22px" src="'.$stat->getUri().'/images/203.png"/></td>';
  echo '</tr><tr>';
  echo '<td style="background:url('.$stat->getUri().'/images/211.png);">&nbsp;</td>';
  echo '<td style="background:url('.$stat->getUri().'/images/212.png);height:100%;">';
  echo "<div id='myStat_date_console' style='position:relative;top:-16px;left:-4px;width:100%;margin-bottom:-19px;'>";
       echo "<div id='myStat_date_panel' style='display:none;width:100%;border:1px solid #9dc584;background:#ABCF95;-webkit-border-radius: 5px;-moz-border-radius: 5px;border-radius: 5px;'>";
       echo "<div style='padding:12px;font-size:10px;'>&nbsp; Выберите период, за который хотите просмотреть статистику. Первая дата - это дата начала построения отчётов. Считать дату начала стоит с указанной даты 00 часов 00 минут 00 секунд. Выбрать дату начала можно максимально за текущий день. Окончание периода считается дата конца периода 23 часа 59 минут 59 секунд.</div>";
       echo "<table width=100% border=0><tr>";
       echo "<td align=center><b>Дата начала периода</b><div class='datePicker' id='mystat_d1cal'></div></td>";
       echo "<td align=center><b>Дата конца периода</b><div class='datePicker' id='mystat_d2cal'></div></td>";
       echo "</tr><tr><td colspan=2 nowrap=nowrap align=center>";
#      $date = $this->rpt->head_page();
#      echo "<pre>";
#      var_dump($date);
#      echo "</pre>";
#           echo "<sup>[ <b onclick=\"\" style='cursor:pointer;".(($var[0][0]==$test_var[0][4] and $var[0][1]==$test_var[0][1])?"color:red;text-decoration:underline;":"")."'>".$this->cmn->T("All")."</b> ] [ <b onclick=\"\" style='cursor:pointer;".(($var[0][0]==$test_var[0][1] and $var[0][1]==$test_var[0][1])?"color:red;text-decoration:underline;":"")."'>".$this->cmn->T("Today")."</b> ] [ <b onclick=\"\" style='cursor:pointer;".(($var[0][0]==$test_var[0][2] and $var[0][1]==$test_var[0][2])?"color:red;text-decoration:underline;":"")."'>".$this->cmn->T("Yesterday")."</b> ] [ <b onclick=\"\" style='cursor:pointer;".(($var[0][0]==$test_var[0][5] and $var[0][1]==$test_var[0][1])?"color:red;text-decoration:underline;":"")."'>".$this->cmn->T("This Week")."</b> ] [ <b onclick=\"\" style='cursor:pointer;".(($var[0][0]==substr($test_var[0][1],0,8).'01' and $var[0][1]==$test_var[0][1])?"color:red;text-decoration:underline;":"")."'>".$this->cmn->T("This Month")."</b> ] [ <b onclick=\"\" style='cursor:pointer;".(($var[0][0]==$test_var[0][3] and $var[0][1]==$test_var[0][1])?"color:red;text-decoration:underline;":"")."'>".$this->cmn->T("Last 7 Days")."</b> ] [ <b onclick=\"\" style='cursor:pointer;".(($var[0][0]==$test_var[0][0] and $var[0][1]==$test_var[0][1])?"color:red;text-decoration:underline;":"")."'>".$this->cmn->T("Last 30 Days")."</b> ]</sup>";
       echo "</td></tr></table><br/>";
       echo "</div>";

       echo "<div style='text-align: right;position:relative;top:-1px;'><table style='margin-left: auto; margin-right: 4px;' border='0' cellspacing='0' cellpadding='0'><tr><td><img src='".$stat->getUri()."/images/top_1.png' /></td><td style='background:url(".$stat->getUri()."/images/top_2.png);font-size:10px;padding-bottom:11px;cursor:pointer;' onclick=\"\$('#myStat_date_panel').slideToggle('slow');\">The report for the period from <b id='myStat_d1'>2009-09-03</b> to <b id='myStat_d2'>2009-10-03</b></td><td><img src='".$stat->getUri()."/images/top_3.png' /></td></tr></table></div>";
#       echo "<script>";
#       echo "\$(function(){\$.datepicker.setDefaults(\$.extend(\$.datepicker.regional['".$stat->getCulture()."']));\$('#mystat_d1cal').datepicker({dateFormat: 'yy-mm-dd',maxDate:'0', showMonthAfterYear: false, defaultDate: new Date(2009,9-1,3)});\$('#mystat_d2cal').datepicker({dateFormat: 'yy-mm-dd',maxDate:'0', showMonthAfterYear: false, defaultDate: new Date(2009,10-1,3)});});";
#       echo "</script>";
  echo "</div>";
  echo '<div id="myStat_main"></div>';
  $stat->printMainPage("myStat_main");
  echo '</td><td style="background:url('.$stat->getUri().'/images/213.png);">&nbsp;</td>';
  echo '</tr><tr height="26px">';
  echo '<td><img width="24px" height="26px" src="'.$stat->getUri().'/images/221.png"/></td>';
  echo '<td style="background:url('.$stat->getUri().'/images/222.png);" width="100%">&nbsp;</td>';
  echo '<td><img width="23px" height="26px" src="'.$stat->getUri().'/images/223.png"/></td>';
  echo '</tr></table>';
};




if(function_exists("register_activation_hook")){
  register_activation_hook(dirname(__FILE__)."/index.php",'myStat_install');
};
if(function_exists("register_deactivation_hook")){
  register_deactivation_hook(dirname(__FILE__)."/index.php",'myStat_deinstall');
};
if(function_exists("load_plugin_textdomain")){
  load_plugin_textdomain('myStat',false, "/".dirname(plugin_basename(__FILE__)).'/languages');
};
if(function_exists("add_action")){
  add_action('admin_menu', 'myStat_menu');
};